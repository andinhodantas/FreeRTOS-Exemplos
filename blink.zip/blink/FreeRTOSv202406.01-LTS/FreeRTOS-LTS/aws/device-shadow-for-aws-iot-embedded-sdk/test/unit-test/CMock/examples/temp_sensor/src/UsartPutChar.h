#ifndef _USARTPUT_HAR_H
#define _USARTPUT_HAR_H

#include "Types.h"

void Usart_PutChar(char data);

#endif // _USARTPUT_HAR_H
